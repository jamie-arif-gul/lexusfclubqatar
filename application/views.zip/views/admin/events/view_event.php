<style>
    .datepicker{
        width: 240px;
    }
</style>
<section id="main-content">
    <section class="wrapper site-min-height">
        <!-- page start-->
        <section class="panel">
            <header class="panel-heading">Event Detail<a href="<?php echo base_url('/administrator/manage_events'); ?>" class="btn btn_back pull-right" type="pull-right ">Back</a></header>
            <div class="panel-body">
                <span>
                    <?php if (isset($success)) {
                        echo '<div class="alert alert-success alert-dismissable"> ';
                        echo '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>';
                        print_r($success);
                        echo '</span>';
                        echo'</div>';
                    } ?>
                </span>
                <span>
                <?php if (isset($errors)) {
                    echo '<div class="alert alert-danger alert-dismissable"> ';
                    echo '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>';
                    print_r($errors);
                    echo '</span>';
                    echo'</div>';
                } ?>
                </span>
                <div class="row">
                    <div class="col-md-12">
                        <div class="col-md-4"><img height="60" width="60" src="<?php echo base_url().'uploads/event_image/'.$event[0]['event_image']; ?>"></div>
                        <div class="col-md-4 ht-60"></div>
                        <div class="col-md-4 ht-60"></div>
                        <div class="col-md-6">
                            <dl class="dl-horizontal">
                                <dt>Name</dt>
                                <dd><?php echo $event[0]['name'] ?></dd>
                                <dt>Description</dt>
                                <dd><?php echo $event[0]['description'] ?></dd>
                                <dt>Location</dt>
                                <dd><?php echo $event[0]['location'] ?></dd>
                            </dl>
                        </div>
                        <div class="col-md-6">
                            <dl class="dl-horizontal">
                                <dt>اسم الحدث</dt>
                                <dd><?php echo $event[1]['name'] ?></dd>
                                <dt>وصف</dt>
                                <dd><?php echo $event[1]['description'] ?></dd>
                                <dt>موقعك</dt>
                                <dd><?php echo $event[1]['location'] ?></dd>
                            </dl>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </section>
</section>




