<div class="col-sm-12 p0">
    <div class="container p0  reg_main_mrg">
        <div class="registration_bg_arabic">
            <p>.شكراً لانضمامكم</p>
            <p>.سوف المشرف الاتصال بك قريبا</p>
        </div>
    </div>
</div>