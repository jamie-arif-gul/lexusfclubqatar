<div class="col-sm-12 p0">
    <div class="container p0 reg_main_mrg">
        <div class="registration_bg">
            <p>Thank you for completing your registration.</p>
            <p>Admin will contact you soon.</p>
        </div>
    </div>
</div>