<div class="col-sm-12 p0">
    <div class="container-fluid p0  reg_main_mrg">
        <div class="registration_bg" id="contact_info">

            <div class="contact_div">
                <h3>LEXUS CALL CENTER</h3>
                <p> Al Abdulghani Tower, Al Matar Street, Najma</p>
                <p style="margin: 0px;"><img src="images/phone.png">8002929 &nbsp; &nbsp;   24 Hours &nbsp; &nbsp;  Sat-Thurs</p>
                <img src="images/message.png"> <a href="#">crm@aabqatar.com  </a>
            </div>

        </div>
    </div>
</div>

<div class="container-fluid p0">
    <div class="col-sm-12 p0 contact_iframe">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d47144.20870013764!2d-71.13876746514832!3d42.39551902105!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89e377297bf5e165%3A0x7a907799d8f97b03!2sSomerville%2C+MA!5e0!3m2!1sen!2s!4v1500541279577" width="100%" height="502" frameborder="0" style="border:0" allowfullscreen></iframe>
    </div>
</div>

<div class="clear40"></div>
<div class="clear40"></div>